package sistemaventa_s01;
//import Vista.Login;

import Vista.Sistema;

public class SistemaVenta_S01 {

    public static void main(String[] args) {

        //Login lg = new Login();
        //lg.setVisible(true);
        Sistema sis = new Sistema();
        sis.setVisible(true);
    }

}
